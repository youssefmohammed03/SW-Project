


    function validate(){
    const user_name = document.getElementById("user_name");
    const pass_word = document.getElementById("pass_word");

    const usernameval = user_name.value.trim();
    const passwordval = pass_word.value.trim();


    if(usernameval == ""){
      alert("Username cannont be blank");
    }
    else if(usernameval.length <=2){
      alert("Username cannont be less than 3 char");
    }
    if(passwordval == ""){
      alert("Password cannont be blank");
    }
    else if(passwordval.length <=5){
      alert("Password cannont be less than 6");
  }
  }